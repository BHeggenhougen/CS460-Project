Names: Ben Heggenhougen, Martin Villasenor, Myles Chen, Olivia Hunter

To run the program:
1. make
2. ./main.x [file name]

Note: Errors are printed out with cerr so they cannot be piped into a file